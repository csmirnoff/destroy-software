*******************************************************************************
"DestroY MediaPlay" Add-On Category for DestroY QuickDesktop (v1.1.0 or higher)
*******************************************************************************

Add-On Description:
-------------------

The "DestroY MediaPlay" Add-On Category for DestroY QuickDesktop allows you to control DestroY MediaPlay from DestroY QuickDesktop. Don't miss the opportunity to combine it with DestroY QuickDesktop's QuickSchedule power!

Items & Categories:
-------------------

Category "DestroY MediaPlay"

- Open DestroY MediaPlay: This item will open DestroY MediaPlay if not running in memory
- Play: This item will make DestroY MediaPlay play the current media file
- Pause: This item will make DestroY MediaPlay pause playback of the current media file
- Stop: This item will make DestroY MediaPlay stop playback
- Previous: This item will start playing the previous media file
- Next: This item will start playing the following media file
- MediaAnnounce: If DestroY MediaPlay's MediaAnnounce is active, it will display MediaAnnounce with the current media information, if not, the information will be displayed in DestroY QuickDesktop's information bar
 
Requirements:
-------------

- DestroY QuickDesktop v1.1.0 or higher
- DestroY MediaPlay v1.1.0 or higher

Notes:
------

- If you later wish to uninstall this add-on, you may do that by executing the add-on setup wizard again, selecting 'Uninstall'�.
- If you have problems with DestroY QuickDesktop after installing this add-on, copy the "addonbak.bak" file you will find in DestroY QuickDesktop's root folder after the add-on installation to the "\Data" folder and rename it to "data.dqd", overwriting the existing file.

Information:
------------

If you don't have DestroY QuickDesktop, download it from: http://www.destroysoftware.com.ar

You can feel free to use this add-on without any charges.
You are not allowed to develope the software back, change, spilt, decompile, disassemble or translate the software product neither in parts nor as whole thing. All rights reserved.

DestroY QuickDesktop
by Christian Smirnoff ("DestroY")
http://www.destroysoftware.com.ar
cas_christian@hotmail.com

DestroY