************************************
DestroY MediaPlay Classic Skins Pack
************************************

Pack Description:
-----------------

Skins pack for DestroY MediaPlay v1.3.0 and higher. This pack includes the 5 Classic skins of the previous versions of DestroY MediaPlay: 

- Default Classic
- Blue Touch Classic
- Green Force Classic
- Aqua Classic
- RedPlay Classic

This pack also includes Visualization and MediaAnnounce images, and features Skin Default Settings for each skin.

Requirements:
-------------

- DestroY MediaPlay v1.3.0 or higher (Important!)

Instructions:
-------------

1) Unzip files into the "...\DestroY MediaPlay\Skins\" folder
2) Open DestroY MediaPlay
3) Open the Settings panel (through MediaTools or right-click menu)
4) Go to the "Skins Browser" section
5) Select the desired skin (Recommended: Enable "Use Skin Default Settings")
6) Click "OK" and enjoy!

If you want to change skin, repeat steps 3 to 6

Credits:
--------

Skins Design
Christian Smirnoff ("DestroY")

Information:
------------

If you don't have DestroY MediaPlay, download it at: http://www.destroysoftware.com.ar

You can feel free to use these skins without any charges.
You are not allowed to edit, change or use this skins as base for your own work without DestroY Software's authorization. All rights reserved.

DestroY MediaPlay
by Christian Smirnoff ("DestroY")
http://www.destroysoftware.com.ar
cas_christian@hotmail.com

DestroY